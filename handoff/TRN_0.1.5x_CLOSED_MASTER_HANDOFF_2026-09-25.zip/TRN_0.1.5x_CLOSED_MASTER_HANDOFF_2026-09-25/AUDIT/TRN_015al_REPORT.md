# TRN 0.1.5al Train-to-Track Alignment Repair Report

## 1. 対象
0.1.5ak の全網監査で抽出した共有線路・論理走行トラックの残存不整合を修正した。
修正前 0.1.5ak は別ファイルとして保存し、本体には上書きしていない。

## 2. 修正内容

### 相鉄・JR直通線：相鉄本線共用区間
相鉄本線側の最新表示Geometryを正本として、直通列車の論理走行トラックを同期した。
対象は西谷以西の共用区間（07〜16）。瀬谷―大和の既一致区間も含め、一貫した共有Geometry参照に統一した。

### 大崎―西大井
この区間は同一駅間の別表示線路が存在しない専用接続線であるため、既存のsource-qualified走行Geometryを変更せず、相鉄・JR直通線の表示対象へ追加した。

### 鶴見線 安善―大川
運行上は安善→大川を1停車区間として扱う一方、表示インフラは安善→武蔵白石＋大川支線に分割されていた。
走行Geometryをこの2本の可視Geometryの合成へ変更し、光点が表示線路上を通るようにした。

### かしわ台―海老名
直通サービス側の終端駅が外部データ由来のopaque station idであったため、走行Geometryを相鉄本線の海老名側へ同期し、当該路線上の表示駅位置もcanonicalな相鉄海老名位置へ合わせた。

## 3. 再監査結果
- 107路線
- 51,422 TrainRun
- 2,858 unique runtime tracks
- 5,474 区間境界
- 6,366 駅停車サンプル

### Gate
- runtime track XY > 1m: **0**
- runtime track Z > 0.5m: **0**
- 区間境界 XY > 1m: **0**
- 区間境界 Z > 0.5m: **0**
- 駅停車 XY > 1m: **0**
- 駅停車 Z > 0.5m: **0**
- shared infrastructure coverage XY > 1m: **0**
- exact shared-pair XY > 1m: **0**
- exact shared-pair Z > 1m: **0**
- Runtime exception: **0**

## 4. nearest-track Z監査の6件について
全表示線路から単純に最寄り線路を選ぶcoverage監査では Z>1m が6件残る。
ただし、同一XY上に山手線・埼京線等が重なるため、別路線をnearestとして拾った結果である。
正しい共有線路とのpair比較では、該当する埼京線・横須賀線とのZ差は全て0m。
したがって残存不整合とは判定しない。

## 5. exact station-pairを持たない4方向
- 鶴見線 安善↔大川 2方向
- 相鉄・JR直通線 かしわ台↔外部データ由来海老名ID 2方向

これらは駅ID構造上exact pairではないが、全表示インフラへのXY coverageは実質0m、Z差も0mであり、表示・走行整合はPASS。

## 6. 判定
**0.1.5akで抽出した11区間のTrain-to-Track alignment問題は0.1.5alで解消。**
次工程は0.1.5xクローズ前の総合回帰監査。
