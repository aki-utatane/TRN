# TRN 0.1.5ai Production Cleanup Report

## 1. 保存措置
修正前の 0.1.5ah は、`TRN_015ah_ARCHIVE_2026-09-21.html` としてそのまま保存した。

- 修正前サイズ: **2,396,100 bytes**
- SHA-256: `91358e7b3b96bad1df10974aaa8211eccb0a32591f160f143851a4d83dedd2bb`
- 保存ファイルは修正前ファイルと byte-identical。
- 旧HTML、旧PACKAGE、旧REPORT、旧AUDIT、SHA記録をまとめた開発アーカイブZIPも作成。

## 2. 軽量化結果

- 0.1.5ah: **2,396,100 bytes**
- 0.1.5ai: **1,942,116 bytes**
- 削減: **453,984 bytes**
- 削減率: **18.95%**

## 3. 主な整理内容

### 実行後監査コードの分離
通常起動後に利用されない、versioned diagnostic export、self-test、hidden runtime audit node生成を本体から除外した。これらは保存済み0.1.5ahに残る。

### 開発計画・QA evidence validatorの分離
Production Removal Plan、最終QA evidence contract等、ランタイム参照が0件の開発管理コードを本体から除外した。

### 起動時self-testの除外
通常利用のたびに実行する必要がない内部simulation self-testを本体起動経路から外した。

### 取得・Bakeツールの分離
既に固定済みデータを再取得・再Bakeするための以下の開発ツールを本体から除外した。

- Tokyo Monorail / transition source qualification audit
- Fukutoshin targeted GROUND_Z acquisition
- Full-network GROUND_Z collector / bake / post-bake audit
- Toei GROUND_Z network collector

### FULL_GROUND_Zの圧縮
1165駅ごとに重複保持していた lat/lon/method/confidence を本体データから整理し、`[groundZ, sourceCode]` の圧縮表現へ変更。起動時に従来互換の `groundZ / groundSource / method / confidence` を再構築する。

- 保存版: 1165 records
- 整理版: 1165 records
- groundZ不一致: **0**
- groundSource不一致: **0**

緯度経度を含む元の完全レコードは開発アーカイブに保存されている。

## 4. 意図的に変更していない領域

- 107路線のネットワーク構造
- 駅ID / 駅位置
- CALIBRATED_RUNTIME_PACKAGE / 運行データ
- 採用済み水平線形補正
- Metro-Z runtime model
- 辰巳ジャンプ修正
- Focus 半径1000m円筒クリッピング
- 駅検索・駅中央移動
- 海岸線データ

## 5. 実行QA

- JavaScript syntax: **PASS**
- Runtime exceptions: **0**
- Canvas: **PASS**
- 時計進行: **PASS**
- Focus ON/OFF: **PASS**
- 駅検索: **PASS**（「新宿」で候補生成）
- 駅選択: **PASS**（新宿、GROUND Z 37.48 m表示）
- LINES: **PASS**（107 toggle）
- METRO Z panel: **PASS**
- YAW control: **PASS**
- hidden runtime audit nodes: **0**

## 6. 残件
今回の目的は「不要な開発資産を本体から分離し、データ等価性を保ったまま軽量化する」こと。さらに大きく削減するには、CALIBRATED_RUNTIME_PACKAGEや水平線形補正の最終Bake/正規化まで踏み込む必要がある。そこは回帰リスクが上がるため、0.1.5aiでは実施していない。

最終的なiPad Safari実機QAは引き続き必要。
