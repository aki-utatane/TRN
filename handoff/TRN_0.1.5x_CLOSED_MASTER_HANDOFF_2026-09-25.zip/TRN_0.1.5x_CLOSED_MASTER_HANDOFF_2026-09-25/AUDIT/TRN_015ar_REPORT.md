# TRN 0.1.5ar REPORT

## Scope
0.1.5aq を基準に、最終UI表記の整理と YAW 時の構図保持を修正した。

## UI changes
1. Station search placeholder: `station` -> `STATION`
   - 検索ボックス自体の幅・高さは変更していない。
2. `STATIONS OFF/ON` -> `LABELS OFF/ON`
   - 実機能（駅名ラベル表示）と表記を一致させた。
3. HEIGHT
   - 表示に `×` を追加。
   - 初期値を x3 -> x10 に変更。
4. VIEW axis
   - TOKYO AXIS の常時表示を廃止。
   - VIEW 操作時のみ表示し、操作後にフェードアウトする動的オーバーレイへ変更。
5. FOCUS
   - ON 表示を `FOCUS 1KM` に変更。
6. MODEL VERSION
   - `DATA MODEL 2026.09 · INFO` / `DATA MODEL` に変更。
7. Station search
   - 検索開始時に既存の駅情報パネルを閉じる。
8. Low-height landscape overlap
   - 低い横画面で DATA MODEL と LINES が重なっていたため、LINES を下へ移動。

## YAW framing fix
### Problem
駅未選択時の YAW 操作で、回転開始時に回転軸を文字通りの画面中央へ取り直し、Pan を再計算していた。
そのため、意図的に上寄せしていたネットワーク表示が中央へ移動することがあった。

### Fix
- 駅未選択時の既定 YAW 軸を stable TOKYO CORE world axis とした。
- YAW 変更時に viewport centre へ回転軸を再配置しない。
- 現在の Pan をそのまま維持する。
- 駅選択時は従来どおり選択駅を回転軸とし、その駅の画面位置を保持する。
- Focus の 1 km 円筒中心および回転軸線も同じ TOKYO CORE / selected station 軸に統一した。

## QA
- JavaScript syntax: PASS
- Runtime exceptions: 0
- Default YAW after manual upward Pan:
  - VIEW 0 deg: Pan delta = 0 px
  - VIEW 30 deg: Pan delta = 0 px
- Selected station YAW screen-position error: 0 px
- Default Focus anchor vs TOKYO CORE: error = 0
- VIEW axis: visible during operation, expired after fade interval
- Search start closes previous station info panel: PASS
- 1024 x low-height landscape:
  - DATA MODEL -> LINES gap = 4.2 px
  - no overlap after adjustment
- HEIGHT initial value: x10
- Station search placeholder: STATION
- Layer label: LABELS OFF/ON
- Focus label: FOCUS 1KM when active

## Not changed
- Network geometry
- TrainRun / timetable model
- speed/headway calibration
- Metro Z runtime models
- Focus radius (1000 m)
- Tatsumi / Roppongi / shared-track fixes
