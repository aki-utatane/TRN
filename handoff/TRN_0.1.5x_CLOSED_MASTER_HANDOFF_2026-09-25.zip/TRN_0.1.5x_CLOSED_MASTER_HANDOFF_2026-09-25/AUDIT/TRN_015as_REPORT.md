# TRN 0.1.5as REPORT

## 修正対象
0.1.5arで、右ドラッグによるYAWおよびYAWボタン操作時に、表示上のZ基準が上下して見える問題を修正した。

## 原因
YAWとVIEWが別の基準点を使用していた。

- 既定YAW軸: TOKYO CORE（山手線中心）
- 駅選択時YAW軸: 選択駅
- VIEW傾斜基準: 東京駅

VIEW基準の東京駅座標までYAW変換していたため、YAWするとVIEWのピッチ基準Yが変化し、Z構造全体が上下して見えた。

## 修正
`tiltPivot013do()` のVIEW/Z基準点をYAW変換から分離した。

- VIEW/Z基準はnorth-up pre-YAW map frameに固定
- YAWはXY線形の向きのみ変更
- YAWによってVIEW/Z基準Yを移動させない
- 一時表示する横軸も実際の固定VIEW基準を表示し、ラベルを `VIEW AXIS` とした

## 回帰確認
VIEW=60°, HEIGHT=x10で確認。

### 既定YAW
- VIEW pivot mapY delta: 0
- VIEW pivot Z delta: 0
- PanY delta: 0
- TOKYO CORE screen Y delta: 0

### 駅選択YAW（新宿）
- screen X delta: 0 px
- screen Y delta: 0 px
- PanX delta: 0
- PanY delta: 0
- VIEW pivot Y delta: 0
- same-point Z screen offset delta: 0 px

### Runtime
- JavaScript syntax: PASS
- Runtime exceptions: 0

## 非変更範囲
以下は変更していない。
- 路線Geometry
- Zモデルそのもの
- HEIGHT=x10
- Focus 1km
- 時刻表・TrainRun
- 駅間速度
- 運行本数
- 駅検索
