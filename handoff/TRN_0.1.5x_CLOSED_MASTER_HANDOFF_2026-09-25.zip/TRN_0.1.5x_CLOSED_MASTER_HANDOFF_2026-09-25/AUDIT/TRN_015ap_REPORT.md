# TRN 0.1.5ap Service Window / Count / Speed Final Audit

## Status
PASS_WITH_REPRESENTATIVE_TIMETABLE_MODEL

## What changed from 0.1.5ao
0.1.5ao had already recalibrated the high-risk short/branch lines identified by the first/last/count audit. A final residual check found three simple full-route lines still materially under-represented by the generic 72/78-run template:

- Seibu Kokubunji Line
- Seibu Tamagawa Line
- Tobu Kameido Line

0.1.5ap replaces only their departure series with representative current-public-timetable cadence. Segment travel times, XY geometry, Z model, YAW, Focus and station search are unchanged.

## Final whole-network gates

- Lines: 107
- TrainRun: 45,861
- Line/day patterns: 214
- Station-to-station speed patterns: 5,920
- Maximum station-to-station average speed: 91.41 km/h (総武快速線 tsudanuma -> inage)
- >110 km/h: 0
- >130 km/h: 0
- Minimum same-line/same-direction segment headway: 120 sec
- Headway <120 sec: 0
- Runtime exceptions: 0
- Stop-offset mismatches vs 0.1.5ao: 0
- Track-list mismatches vs 0.1.5ao: 0

## Final residual recalibrations

### Seibu Kokubunji Line
Current public timetable pattern shows peak service in the roughly 6-10 minute range and a daytime pattern around 10 minutes. The generic model was too sparse.

- Weekday total TrainRun: 214
- Holiday total TrainRun: 204
- First/last direction-specific times are aligned to the current published pattern (roughly 05:04/05:20 start and around midnight finish depending on direction).

### Seibu Tamagawa Line
The published timetable is approximately 12-minute service through most of the day, with wider early/late gaps.

- Weekday total TrainRun: 177
- Holiday total TrainRun: 177
- Representative service window: about 05:28/05:31 to 00:27/00:09 depending on direction.

### Tobu Kameido Line
Current timetable shows a denser peak and roughly 10-minute daytime/evening operation. The old 72/78-run template materially under-represented the service.

- Weekday total TrainRun: 231
- Holiday total TrainRun: 218
- Representative service window: about 05:34/05:43 to 00:18/00:29 depending on direction.

## Interpretation
The objective is not exact reproduction of every train number. The gate is whether the visualization materially misrepresents first/last service, daily density, train spacing or station-to-station movement. Under that standard, the remaining high-risk discrepancies found during this audit have been corrected.

## Remaining limitations
- Some major lines remain representative service models rather than exact public timetables.
- Event-day / special-service variations are not modeled as exact event calendars.
- Timetable source dates vary by operator; current public information was checked where the risk-based audit identified anomalies.
