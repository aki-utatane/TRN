# TRN 0.1.5aq Final Regression Report

Date: 2026-09-24
Status: PASS / 0.1.5x closure candidate

## Scope
Final regression audit after 0.1.5x development, including:
- station search and centering
- station-selected YAW pivot
- 5000% diagnostic zoom
- compass north reset
- VIEW / Focus interaction
- Focus 1000 m cylinder clipping
- LINES / station-search panel exclusion
- simulation clock and speed control
- UI overlap at 1024x768 and 1024x560
- METRO Z comparison UI retirement

This audit does not change network geometry, Z data, timetable data, service counts, or speed calibration. 0.1.5aq differs from 0.1.5ap only by retiring the visible METRO Z comparison UI and updating the version.

## Changes in 0.1.5aq
- Removed the visible METRO Z button/panel from the normal UI.
- Retained integrated runtime Z models internally.
- Marunouchi remains on the current runtime model; the review-only candidate is not promoted.
- Removed the METRO Z / map-layer-control overlap in the lower-left UI.

## Runtime / UI audit
### Startup
- Title: 東京鉄道網シミュレーター 0.1.5aq
- Visible version: PROTOTYPE 0.1.5aq
- Lines active: 107/107
- Focus default: OFF
- YAW default: North
- VIEW default: 0 degrees
- Zoom default: 100%
- Runtime exceptions: 0
- Console errors: 0

### Station search / centering
Search term: 新宿
- 9 search results returned.
- First result selected: 新宿 / yamanote pivot.
- Search result panel closes after selection.
- Station information panel opens correctly.

Station-center error:
- 100%, YAW 0: ~8.0e-14 px (numerical zero)
- 100%, YAW 90: ~8.0e-14 px
- 5000%, YAW 180: 0 px
- 5000%, YAW 270: 0 px

Result: PASS. The searched/selected station remains the exact screen rotation centre even at 5000% diagnostic zoom.

### Focus
- Focus ON works.
- Changing VIEW to 30 degrees automatically clears Focus.
- Focus model is a hard horizontal 1000 m cylinder with unlimited Z.
- Sampled world points: 12,807 total.
  - inside-cylinder samples: 165
  - outside-cylinder samples: 12,642
  - incorrect alpha decisions: 0
- Nearest sampled point inside boundary: 989.87 m -> visible
- Nearest sampled point outside boundary: 1011.09 m -> hidden

Result: PASS.

### Compass / YAW
Test state before compass click:
- YAW: E
- Zoom: 122%
- VIEW: 30 degrees

After compass click:
- YAW: N
- Zoom: 122% retained
- VIEW: 30 degrees retained

Result: PASS.

### Zoom Reset
- Zoom returns to 100%.
- VIEW is preserved.
- YAW is preserved.

Result: PASS.

### LINES / station search mutual exclusion
- LINES panel opens normally.
- Beginning station search closes the LINES panel.
- Search results remain available.

Result: PASS.

### Clock / speed control
- x240 speed button becomes active correctly.
- Simulation clock advances at accelerated rate.

Result: PASS.

## Layout audit
### 1024 x 768
Checked fixed UI elements:
- LINES / station search
- STATIONS / COASTLINE / FOCUS
- YAW controls
- VIEW / HEIGHT
- footer controls
- clock

Overlap area: 0 px².

### 1024 x 560
Same fixed UI elements checked.
Overlap area: 0 px².

Station-search result panel at 1024x560:
- x=16, y=121.5
- width=290, height=140
- right=306 < viewport 1024
- bottom=261.5 < viewport 560
- LINES panel hidden while results are open

Result: PASS.

## Previous subsystem audits inherited unchanged
0.1.5aq does not modify the following validated data/runtime areas from 0.1.5ap and prior builds:
- 107-line network
- train-to-track XY/Z alignment
- Yurakucho Tatsumi continuity repair
- Oedo Roppongi direction-specific two-layer display repair
- shared-infrastructure alignment repair
- service-window / first-train / last-train recalibration
- service-count recalibration
- speed / headway audit
- max station-to-station average speed 91.41 km/h
- no >130 km/h average segment
- no headway group below 120 seconds

## Final assessment
0.1.5aq passes the final regression audit for the 0.1.5x development scope.

Recommended state:
- 0.1.5x development scope: CLOSE CANDIDATE
- Current deliverable: 0.1.5aq
- Marunouchi review-only Z candidate: retained internally, not promoted; current model accepted for now by user direction.
- METRO Z comparison UI: retired from normal UI.
