# MASTER SPEC — TRN 0.1.5x

## 1. 基本コンセプト

TRNは鉄道ゲームではなく、**都市鉄道網の時刻運行・線路形状・高低差を観察するための可視化シミュレーター**である。

表現原則：
- 黒背景
- 路線はネオン状の細線
- 列車は路線色の光点
- 駅・路線名は必要なときだけ補助表示
- 常時ラベルで地図を埋めない
- UIは地図観察を邪魔しない透過設計

## 2. Viewport

### Zoom
- 100%～5000%
- 高倍率は地下立体構造・交差構造の検証用途を含む
- Zoom reset と VIEW RESET は役割を混同しない

### Pan
- 通常Panは画面構図をユーザーが決めるための操作
- YAW操作によってPanを勝手に再センタリングしない

### VIEW
- 0°～90°
- 水平地図から立体断面寄りの視点まで連続的に変更
- VIEW操作時は一時的な `VIEW AXIS` を表示し、その後フェードアウト
- VIEW変更時はFOCUSを解除する（迷子防止）

### HEIGHT
- Z誇張倍率
- 表示は `×N`
- 0.1.5xクローズ時デフォルト：**×10**

## 3. YAW

### 目的
水平面内で鉄道網を回転させ、地下/高架構造を異なる方位から観察する。

### 既定軸
- 駅未選択時：**TOKYO CORE world vertical axis**
- 駅選択時：選択駅のworld vertical axis

### UI
- 左：反時計回り
- 中央：方位コンパス / N E S W
- 右：時計回り
- コンパス本体クリック：YAW=0°（北）
- 右マウス水平ドラッグ：連続YAW

### 重要挙動
- 駅選択時、駅の画面位置をYAW前後で固定する
- 駅未選択時、YAWでPanを中央へ吸着させない
- YAWはVIEW/Z基準を上下させない
- 右ドラッグはpointerdownからの絶対移動量で追従
- `buttons` bitmaskの途中欠落には依存しない

## 4. Focus

- 表示名：`FOCUS OFF` / `FOCUS 1KM`
- 中心：現在のYAW回転軸
- 水平半径：1000m
- Z方向：無制限
- 1000m以内：通常描画
- 1000m外：非表示
- 適用：線路、駅マーカー、列車光点
- 境界をまたぐ線路は円筒内部分のみ描画
- 同一路線の可視連続区間を連続Pathとして描き、駅間ごとのstroke分断を避ける

## 5. Station search

- 左側UI、LINESの下
- 枠サイズはLINES/COASTLINE等の基本幅と合わせる
- 白い虫眼鏡
- placeholder: `STATION`
- 入力開始でplaceholder消去
- 候補一覧だけは駅名/路線名可読性のため横へ展開可
- LINES展開と検索候補は排他表示
- 検索開始時は既存駅情報パネルを閉じる
- 駅選択で画面中央へ移動し、YAW軸へ設定

## 6. Left UI

常時表示UIは右側VIEW/HEIGHTおよびフッターと同系統の透過処理を行う。

主要項目：
- LINES
- STATION search
- LABELS
- COASTLINE
- FOCUS

旧 `METRO Z` は開発比較UIであり、0.1.5xクローズ前に通常UIから撤去済み。

## 7. Right UI

- VIEW
- HEIGHT
- 半透明、地図を遮蔽しすぎない
- 無断で新規情報パネルを追加しない

## 8. Footer / clock

- 曜日＋時刻
- Speed倍率
- VIEW状態等
- YAW UIは簡潔な3ブロック構造
- 不要な説明文やデバッグ表示を常設しない

## 9. Network / Line rendering

- OFF路線は文脈用ghost表示という設計を含む
- Focus ON時はFocusルールが優先
- 海岸線は補助レイヤーで、路線より強く主張しない
- station labels は `LABELS` で切替

## 10. Train rendering

- 路線色の光点
- DWELLING / RUNNING 状態を持つ
- 列車位置は運行トラックGeometry上を進む
- 表示線路と論理走行トラックのXY/Z整合を維持
- 方向別Zが存在する場合は、必要な表示線路も方向別に表現する

## 11. ターゲット品質

- iPad Safariで操作可能
- 単一HTMLでオフライン起動可能
- 通信を必須にしない
- 高Zoomでも回転軸・Z表示・光点が破綻しない
