# SOURCE / CONFIDENCE POLICY

## 原則

1. 一次資料を優先。
2. 二次資料のみの場合は、その事実をsource ID・confidenceで残す。
3. 推定値を実測・公式値のように表現しない。
4. C-confidenceはモデル成立のための推定値であり、測量値ではない。
5. 外部データを更新する場合、既存モデルとの差分を確認してからApplyする。

## Confidence

### A
公的・公式・高信頼の直接資料に基づく。

### B
公的資料の間接参照、公式ハンドブック等を介した十分な裏付け。

### C
二次資料、構造上の推定、クロスチェックを含む。使用可だが確定値として扱わない。

## 最終HTMLに確認できる代表source ID

### Ground
- `GSI_DEM1A_2026`
- `GSI_DEM5A_2026`
- `GSI_DEM5B_2026`

### Station / XY
- `EKIDATA_STATION_POSITIONS`
- GSI由来horizontal geometry correction群

### Tokyo Metro / Toei Z関連（代表）
- `TOKYO_METRO_ADMIN_PROFILE_ALIGNMENT_013Q`
- `TOKYO_METRO_CABINET_PROFILE_SOURCE_013N`
- `TOKYO_METRO_MODEL_CUT_EVIDENCE_013S`
- `TOEI_OFFICIAL_VERTICAL_013L`
- `SECONDARY_MARUNOUCHI_DEPTH_LIST_CROSSCHECK_2015`
- `SECONDARY_HANZOMON_DEPTH_LIST_CROSSCHECK_2015`
- `SECONDARY_NAMBOKU_DEPTH_LIST_CROSSCHECK_2015`

これらのsymbolic source IDについて、最終HTMLに元URLが残っていないものがある。将来その区間を更新する場合は、IDから勝手にURLを推定せず、元調査資料または再調査で確認する。

## 代表的な時刻表照合元

0.1.5x後半の監査で使用した公式・準公式公開元の例：
- JR東日本 時刻表: https://timetables.jreast.co.jp/
- 東京メトロ: https://www.tokyometro.jp/
- 秩父鉄道: https://www.chichibu-railway.co.jp/train/download.html
- 小湊鐵道: https://www.kominato.co.jp/timetable/
- 西武鉄道: https://www.seiburailway.jp/ （時刻表表示は関連公式サービスを使用）
- 東京ディズニーリゾートライン: https://www.tokyodisneyresort.jp/tdr/resortline/station

※この一覧は全sourceの完全な書誌ではない。過去監査reportもAUDITフォルダに同梱している。
