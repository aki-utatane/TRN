# TRN 0.1.5x CLOSED — START HERE

## 1. このパッケージの目的

これは「東京鉄道網シミュレーター（TRN）」0.1.5x の正式クローズ版と、別アカウント・別チャット・別担当AIでも開発を再開できるようにするための MASTER HANDOFF PACKAGE です。

**最重要事項：最終安定版は `FINAL/TRN_0.1.5x_CLOSED_FINAL__build_0.1.5at.html` です。**

0.1.5at は、0.1.5x 系列の最終ビルドとして 2026-09-25 に正式クローズされました。右マウスドラッグYAW追従およびYAW時のZ表示安定性についてユーザー実機確認済みです。

## 2. 再開時に最初に読む順番

1. `DOCS/CURRENT_STATE.md`
2. `DOCS/MASTER_SPEC.md`
3. `DOCS/REGRESSION_GUARD.md`
4. `DOCS/KNOWN_LIMITATIONS_AND_FUTURE.md`
5. 必要に応じて `DATA_MODEL_SPEC.md` / `Z_MODEL_SPEC.md` / `TIMETABLE_MODEL_SPEC.md`
6. 開発経緯を追う場合は `DEVELOPMENT_HISTORY.md` と `DECISION_LOG.md`

個人アカウントへ移行して最初のチャットを開始する場合は、`DOCS/START_PROMPT_PERSONAL_ACCOUNT.md` をそのまま貼り付けてください。

## 3. 開発上の絶対ルール

- 0.1.5at を「正しい出発点」とし、過去版へ不用意に戻さない。
- 既にPASSしたモデル・修正を、根拠なく再設計しない。
- 変更前には必ず現在版を保存する。
- 変更は小さな差分単位で行い、影響範囲に対応する回帰監査を行う。
- iPad Safari を最重要端末として扱う。
- Z/深度/地盤高などは source / confidence を維持し、不明値を「実測値」として扱わない。
- 時刻表は代表運行モデルであり、全列車番号を1対1再現するものではない。
- 正本・基準版への昇格はユーザーの明示指示なしに行わない。

## 4. 現在の到達点

0.1.5x で次の主要領域を完了しました。

- 水平方向YAW回転
- 駅選択による回転軸
- 回転軸表示
- VIEW / HEIGHT とYAWの整合
- Focus 1km円筒クリッピング
- 駅検索と中央移動
- コンパスクリック北向き復帰
- 全網Train-to-Track整合監査
- 辰巳ジャンプ修正
- 大江戸線六本木方向別Z表示修正
- 共有線路の走行Geometry整合
- 駅間速度・運行間隔・始発/終電・本数の代表モデル再較正
- Production Cleanup（一次）
- 最終UI回帰監査

## 5. 何を「未解決」と誤認しないこと

過去のチャットには検討途中の候補・PoC・失敗案が多数あります。最終状態は本パッケージの `CURRENT_STATE.md` と `CLOSEOUT_STATUS.json` を優先してください。

特に、辰巳ジャンプ、大江戸線六本木の線路外走行、Focusのシャギー、秒単位TrainRun重複、YAWによるZ上下移動、右ドラッグ追従不良は**修正済み**です。
