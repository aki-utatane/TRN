# UI / UX SPEC

## 原則

- 地図が主役。UIは主張しすぎない。
- 一般的でない操作は、見た目・補助UIで理解可能にする。
- iPad Safariでの誤操作・重なりを避ける。
- 左/右/フッターの透過トーンを統一する。
- 不要な開発・監査UIを通常画面に残さない。

## 左側

標準順序：
- DATA MODEL ... INFO
- LINES
- STATION検索
- LABELS
- COASTLINE
- FOCUS

### STATION
- LINESと同一基本幅
- 虫眼鏡は白
- placeholder `STATION`
- 候補リストは必要時のみ横へ展開
- LINESと候補は排他

### LABELS
- 駅マーカーそのものではなく駅名表示のON/OFF
- 旧 `STATIONS OFF` は意味不一致のため `LABELS OFF/ON` に変更

### FOCUS
- OFF / 1KM
- 1000m円筒外は非表示

## 右側

- VIEW
- HEIGHT ×N
- HEIGHTデフォルト ×10
- 背景透過とblur

## YAW

3ブロック構成：
- ↺
- N/E/S/W compass
- ↻

コンパス本体クリック：北向き復帰。

回転軸の白線：
- 実線
- 回転操作の継続に応じ濃くなる
- 操作終了後にフェードアウト

## VIEW AXIS

- VIEW操作時だけ表示
- 常設しない
- フェードアウト

## パネル重なり

0.1.5aq最終回帰では1024×768および1024×560で固定UI重なり0を確認。
0.1.5arで低高さ横画面のDATA MODEL / LINES間ギャップを追加調整。

新しい常設パネルを追加する場合は必ず低高さ横画面で重なりを確認する。
