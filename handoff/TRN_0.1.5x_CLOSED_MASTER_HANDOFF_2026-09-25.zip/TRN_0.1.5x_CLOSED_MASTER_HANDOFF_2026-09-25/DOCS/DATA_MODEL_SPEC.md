# DATA MODEL SPEC

## 概要

0.1.5xは単一HTML内にネットワーク、Geometry、Z、時刻運行データ、UIロジックを内包する。最終HTMLでは累積開発由来の互換レイヤーが残っているため、改修時は「最終effectiveデータ」がどれかを必ず確認する。

## Station

中心的なstation registryは `stationById`。

概念フィールド：
- id
- name
- x / y（TRN内部平面座標）
- lat / lon（元データまたは補助情報として存在する場合）
- lineごとの `displayStationPositions` により表示位置を上書きする場合あり
- ground Z / track Z は別レイヤーで評価

## Line

registry: `lineById`

概念フィールド：
- id
- name
- operator
- color
- stationIds
- displayTrackIds
- displayTrackGroups
- displayStationPositions
- defaultDepth

`displayTrackGroups` は路線の複数表示系統・環状線・方向別表示等で重要。

## Track

registry: `trackById`

概念フィールド：
- id
- lineId
- fromStationId
- toStationId
- geometry[]
- length

Geometryは列車走行と表示線形の両方に関係する。共有インフラでは、論理走行トラックと表示トラックが別IDの場合があるため、同期関係を壊さないこと。

## Runtime timetable package

基礎パッケージ：`CALIBRATED_RUNTIME_PACKAGE`

最終effective系列は累積較正を経て、0.1.5xでは `CALIBRATED_RUNTIME_PACKAGE_EFFECTIVE_015AP` がruntime networkへ渡される。

圧縮フィールド例（実コード）：
- `id`: line id
- `r`: route rows
- route `i`: route id
- `p`: weekday/holiday pattern
- `d`: direction label
- `o` / `z`: origin / terminal station id
- `k`: track id list
- `s`: stop timing rows
- `x`: departure/start series

これは可読性より単一HTMLサイズ削減を優先した圧縮表現を含む。

## Simulation engines

実コードには次のクラスが存在する。
- `SimulationClock`
- `SimulationEngine`
- `TimetableSimulationEngine`
- `HybridSimulationEngine`
- `CalibratedSimulationEngine`

列車のRUNNING位置はtrack Geometry、DWELLING位置はstation/track endpoint整合に依存する。

## Source of truth の注意

同じデータに対し、過去バージョンの補正関数が複数存在する場合がある。改修時は「定義があるから使用中」と判断せず、最終runtime objectがどのeffective定数を参照しているかを追跡する。

0.1.5xクローズ時の原則：
- network runtime: final network object
- timetable runtime: `CALIBRATED_RUNTIME_PACKAGE_EFFECTIVE_015AP`
- Z runtime: current promoted models（METRO Z比較UIは撤去済み）

## 将来の外部データ取込契約

将来は直接コードを書換える方式ではなく、次のパイプラインを採る。

**Import → Normalize → Validate → Diff → Apply**

対応対象：
- 駅追加/変更
- 路線追加/延伸
- Geometry変更
- 時刻表変更
- 運行本数変更

0.1.5xではこのアーキテクチャ契約のみ確定。汎用Importerは未実装。
