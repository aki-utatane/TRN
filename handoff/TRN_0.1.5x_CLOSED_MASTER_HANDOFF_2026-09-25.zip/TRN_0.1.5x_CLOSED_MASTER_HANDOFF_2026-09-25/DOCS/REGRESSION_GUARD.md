# REGRESSION GUARD — MUST READ BEFORE EDITING

変更後に該当領域を必ず再確認する。

## A. Geometry / train alignment

- [ ] 列車光点が表示線路上を走る
- [ ] 区間境界でXYジャンプしない
- [ ] 区間境界でZジャンプしない
- [ ] 停車→発車で駅位置から直角に飛ばない
- [ ] 共有線路を走る論理トラックが最新表示Geometryと同期している

重点回帰地点：
- [ ] 有楽町線 辰巳―新木場 / 豊洲―辰巳
- [ ] 大江戸線 六本木前後
- [ ] 相鉄・JR直通線の共有区間
- [ ] 鶴見線 大川支線

## B. Z

- [ ] YAWだけでZ構造全体が上下しない
- [ ] VIEW 60° / HEIGHT ×10でYAW前後のZオフセットが変わらない
- [ ] 駅選択YAWでも選択駅の画面位置が固定
- [ ] 既定YAWでもPanが勝手に再センタリングされない

## C. YAW / right mouse drag

- [ ] 右ドラッグがpointerdownからpointerupまで連続追従
- [ ] `buttons` bitmaskが途中で0になっても追従停止しない
- [ ] 右100pxドラッグで概ね25°相当（0.25°/px）の変化
- [ ] pointerupで最終位置を反映
- [ ] コンパスクリックで北へ戻る
- [ ] 北復帰でZoom / VIEW / HEIGHTを勝手に変えない

## D. Focus

- [ ] 中心が現在のYAW軸と一致
- [ ] 半径1000m内は表示
- [ ] 半径1000m外は非表示
- [ ] Z方向は制限しない
- [ ] 線路・駅・列車に同じ判定
- [ ] Focus ONで路線にシャギー/駅間継ぎ目が出ない
- [ ] VIEW変更でFocus解除

## E. Station search

- [ ] STATION placeholder
- [ ] 入力開始でplaceholder消去
- [ ] 候補から駅選択→画面中央
- [ ] 選択駅→YAW軸
- [ ] 検索候補とLINES一覧が同時に開かない
- [ ] 低高さiPad横画面で候補が画面外へはみ出さない

## F. Timetable / speed

- [ ] 120秒未満の不自然な重複TrainRun = 0
- [ ] 駅間平均速度の異常値 = 0
- [ ] 川越線等の較正済み所要時間を戻さない
- [ ] 鶴見線の枝系統を別テンプレートで重複生成しない
- [ ] 短支線を一律5分間隔テンプレートへ戻さない
- [ ] 始発/終電の大幅外れが再発しない

## G. UI

- [ ] 左・右・フッターの透過感が統一
- [ ] 1024×768で固定UI重なりなし
- [ ] 1024×560で固定UI重なりなし
- [ ] HEIGHTは `×N`
- [ ] LABELSの文言が機能と一致
- [ ] METRO Z開発UIを通常画面へ戻さない

## H. Delivery

- [ ] 変更前HTMLを保存
- [ ] version更新
- [ ] JavaScript syntax check
- [ ] Runtime exception確認
- [ ] 変更範囲に応じた監査JSON/レポート
- [ ] 正本昇格はユーザー明示指示のみ
