# VERSION HISTORY — SUMMARY

| Series / Build | 主目的 | 結果 |
|---|---|---|
| 0.1.0x | 基本可視化 | 黒背景・ネオン路線・列車光点・基本UI |
| 0.1.1x | 時刻モデル | 始発/終電/本数代表較正 |
| 0.1.2x | ネットワーク拡張 | 外縁内未収録路線、海岸線、枝線修正 |
| 0.1.3x | Zモデル | Ground Z / Track Z / Metro / hub precision |
| 0.1.4x | 全網Z監査 | Z realism audit、Zoom 5000、UI整理 |
| 0.1.5x | YAW・Focus・検索・クロージング | 0.1.5atで正式クローズ |

## 0.1.5 sub-builds

| Build | 主要変更 |
|---|---|
| x | YAW、station pivot、Focus、Tatsumi初期修正 |
| y | runtime audit integrity修正 |
| z | Focus/View連動、axis表示、Tatsumi追加修正 |
| aa-ac | Focus円筒設計の再調整 |
| ad | 円筒外完全非表示 |
| ae | 駅検索・中央移動 |
| af | 検索UIコンパクト化 |
| ag-ah | Focus線路シャギー修正 |
| ai | Production Cleanup |
| aj | 大江戸線六本木方向別Z表示 |
| ak | compass north + alignment audit |
| al | 共有線路11区間修正 |
| am | 左UI透過 + Marunouchi review |
| an | speed/headway修正 |
| ao | service window/count較正 |
| ap | final count recalibration / timetable audit PASS |
| aq | final regression candidate / METRO Z UI撤去 |
| ar | UI terminology / HEIGHT×10 / YAW composition |
| as | YAW-Z datum decoupling |
| at | RMB absolute drag tracking / 0.1.5x final |
